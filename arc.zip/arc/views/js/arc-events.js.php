var filterQuery = '<?= isset($filterQuery)?validJsStr($filterQuery):'' ?>';
var sortQuery = '<?= isset($sortQuery)?validJsStr($sortQuery):'' ?>';
